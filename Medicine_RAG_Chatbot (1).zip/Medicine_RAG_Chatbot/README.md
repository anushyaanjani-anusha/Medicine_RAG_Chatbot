# Medicine Label RAG Chatbot

An educational full-stack RAG project that answers questions from official medicine label excerpts. It includes a Streamlit frontend (`app.py`), a FastAPI backend (`api.py`), and PostgreSQL with pgvector. Responses include source links and are restricted to retrieved evidence.

## Important scope

This is a student prototype for general information. It does not diagnose, recommend treatment, or personalize dosing. Labels differ by product and jurisdiction. For individual medication decisions, contact a licensed clinician or pharmacist. For emergencies or suspected overdose, contact local emergency services or poison control.

## Contents

- `app.py` - frontend with a reference-style sidebar menu for Chatbot, RAG Pipeline, and Info. Info includes Description and Technologies Used pages, and Description catalogs each actual PDF and can generate a short summary from its extracted text.
- `api.py` - backend API and retrieval-augmented answer generation.
- `rag_engine.py` - PDF and sidecar ingestion, PostgreSQL/pgvector indexing, retrieval, source formatting, and generation logic.
- `ingest.py` - loads the four local source records and indexes them.
- `datafiles_docs/` - four human-readable PDFs plus their machine-readable official-source JSON records.
- `docs/` - project documentation and presentation.
- `docker-compose.yml` - local multi-service setup.

## Start locally

1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and add an OpenAI API key.
3. From this folder, run `docker compose up --build`.
4. Open the Streamlit frontend at `http://localhost:8501`. FastAPI docs are at `http://localhost:8000/docs`.
5. On first startup, the backend initializes the vector table and ingests the supplied records. If you change `OPENAI_API_KEY`, restart the stack.

The project uses a specific `gpt-4o-mini` default, configurable through `OPENAI_CHAT_MODEL`. API keys stay server-side in `.env` and must never be committed.

## Data sources

The four source PDFs contain selected label sections retrieved from the openFDA drug labeling API. They are official-label data excerpts, not AI-generated medicine content. Each PDF and JSON record contains the API source URL and retrieval date. The openFDA documentation cautions that its data should not be used by itself for medical-care decisions and may not match products currently distributed.

## GitHub and Drive submission

Create a GitHub repository from this folder, then put its URL and the deployed app URL in `docs/PROJECT_DOCUMENTATION.docx` and the final presentation. Upload the project folder to a team Google Drive folder, grant access to the six team members and the instructor, and add six individual video files to `videos/`. These account-specific sharing and publishing steps require your team accounts.

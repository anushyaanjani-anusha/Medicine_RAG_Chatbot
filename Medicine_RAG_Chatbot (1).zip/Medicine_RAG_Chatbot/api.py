"""FastAPI service for the medicine label RAG chatbot."""
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from rag_engine import answer, describe_document, init_db, ingest_sources, list_documents


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    try:
        ingest_sources()
    except Exception as exc:
        # Keep the service up so the health route explains configuration issues.
        app.state.ingest_error = str(exc)
    yield


app = FastAPI(title="Medicine Label RAG API", version="1.0.0", lifespan=lifespan)


class ChatRequest(BaseModel):
    question: str = Field(min_length=3, max_length=1500)
    medicine: Optional[str] = Field(default=None, max_length=120)


class DescribeRequest(BaseModel):
    slug: str = Field(min_length=1, max_length=80, pattern=r"^[a-z0-9_-]+$")


@app.get("/health")
def health():
    return {"status": "ok", "ingest_error": getattr(app.state, "ingest_error", None)}


@app.get("/documents")
def documents():
    return {"documents": list_documents()}


@app.post("/documents/describe")
def document_description(payload: DescribeRequest):
    try:
        return describe_document(payload.slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Description service unavailable: {exc}") from exc


@app.post("/chat")
def chat(payload: ChatRequest):
    try:
        return answer(payload.question, medicine=payload.medicine)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Chat service unavailable: {exc}") from exc

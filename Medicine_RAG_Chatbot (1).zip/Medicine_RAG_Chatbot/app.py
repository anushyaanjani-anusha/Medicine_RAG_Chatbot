"""Medicine RAG chatbot with reference-style navigation and PDF catalog."""
import os
import requests
import streamlit as st

BACKEND = os.getenv("BACKEND_URL", "http://localhost:8000")
st.set_page_config(page_title="Medicine Uses RAG Chatbot", page_icon="💊", layout="wide", initial_sidebar_state="expanded")
st.markdown("""<style>
[data-testid="stSidebar"] { min-width: 260px; max-width: 260px; }
.main-title { text-align: center; font-size: 31px; font-weight: 700; color: #176B87; }
.sub-title { text-align: center; color: #667085; font-size: 16px; }
</style>""", unsafe_allow_html=True)

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

st.sidebar.title("💊 MEDICINE CHATBOT")
st.sidebar.caption("MEDICINES, USES AND SAFETY")
st.sidebar.divider()
page = st.sidebar.radio("Navigation", ["Chatbot", "RAG Pipeline", "Info"], key="main_navigation")
info_page = None
if page == "Info":
    st.sidebar.subheader("Information")
    info_page = st.sidebar.radio("Info pages", ["Description", "Technologies Used"], key="info_navigation", label_visibility="collapsed")
st.sidebar.divider()
st.sidebar.caption("Retrieval Augmented Generation System")

if page == "Chatbot":
    st.markdown('<p class="main-title">MEDICINES AND THEIR USES</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">AI-Powered Retrieval Augmented Generation Chatbot</p>', unsafe_allow_html=True)
    st.caption("Ask about uses, ingredients, warnings, and side effects in the supplied medicine label files.")
    st.divider()
    st.info("Educational information only. The chatbot does not diagnose, recommend treatment, or provide doses. Ask a doctor or pharmacist about personal medication decisions.")
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("sources"):
                with st.expander("📚 View label sources"):
                    for source in message["sources"]:
                        st.markdown(f"**{source['medicine']} — {source['section']}**  \nRetrieved {source['retrieved_at']} · relevance {source['score']}  \n[Open official label source]({source['url']})")
    question = st.chat_input("Ask a question about a medicine...")
    if question:
        st.session_state.chat_history.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant"):
            with st.spinner("Searching medicine label documents..."):
                try:
                    response = requests.post(f"{BACKEND}/chat", json={"question": question}, timeout=90)
                    response.raise_for_status()
                    result = response.json()
                    st.markdown(result["answer"])
                    if result.get("sources"):
                        with st.expander("📚 View label sources"):
                            for source in result["sources"]:
                                st.markdown(f"**{source['medicine']} — {source['section']}**  \nRetrieved {source['retrieved_at']} · relevance {source['score']}  \n[Open official label source]({source['url']})")
                    st.session_state.chat_history.append({"role": "assistant", "content": result["answer"], "sources": result.get("sources", [])})
                except Exception as exc:
                    st.error(f"Could not reach the chatbot backend. Check the services and API key. Details: {exc}")
        st.rerun()
    if st.button("🗑️ Clear Chat"):
        st.session_state.chat_history = []
        st.rerun()
    st.caption("For a suspected overdose, severe reaction, or urgent symptoms, contact local emergency services or poison control.")

elif page == "RAG Pipeline":
    st.title("🔄 RAG PIPELINE")
    st.subheader("How the medicine chatbot finds and explains label information")
    st.graphviz_chart(r'''digraph RAG {
      rankdir=TB; graph [bgcolor="transparent", nodesep=0.35, ranksep=0.4];
      node [shape=box, style="rounded,filled", fillcolor="#E4F2F5", color="#176B87", fontname="Arial", fontsize=11];
      edge [color="#667085", arrowsize=0.7];
      A [label="Official medicine label PDFs and JSON"];
      B [label="Extract label sections"];
      C [label="Split into overlapping passages"];
      D [label="Create text embeddings"];
      E [label="Store passages and vectors in PostgreSQL + pgvector"];
      F [label="User question"];
      G [label="Embed question"];
      H [label="Cosine similarity search"];
      I [label="Retrieve relevant label passages"];
      J [label="LLM writes a grounded answer"];
      K [label="Show answer with source links"];
      A -> B -> C -> D -> E;
      F -> G -> H -> I;
      E -> H;
      I -> J -> K;
    }''')
    st.warning("The chatbot can retrieve an incomplete or mismatched passage. Check that the cited medicine and label section match your question.")

elif page == "Info" and info_page == "Description":
    st.title("📖 PROJECT DESCRIPTION")
    st.subheader("Medicine Uses and Label Information Chatbot")
    st.write("This application searches official medicine-label excerpts and uses a language model to explain the passages it finds. It demonstrates retrieval-augmented generation (RAG) with linked sources so users can inspect the underlying label.")
    st.write("The project dataset currently includes acetaminophen, ibuprofen, amoxicillin, and metformin. Each record includes available label sections such as uses or purpose, ingredients, warnings, and adverse reactions. The individual source files can differ by product and may not apply to every formulation.")
    st.warning("This project is for general education. It does not diagnose, recommend treatment, or provide doses. For personal medicine decisions, consult a licensed doctor or pharmacist.")
    st.divider()
    st.subheader("Medicine source files")
    try:
        response = requests.get(f"{BACKEND}/documents", timeout=20)
        response.raise_for_status()
        docs = response.json().get("documents", [])
        if not docs:
            st.info("No source PDFs were found in the project data folder.")
        for doc in docs:
            with st.container(border=True):
                st.markdown(f"#### 📄 {doc['pdf_name']}")
                st.caption(f"{doc['medicine']} · {doc['pdf_pages']} page(s) · {doc['pdf_size_kb']} KB · Retrieved {doc['retrieved_at']}")
                st.write("**Label sections:** " + (", ".join(doc["sections"]) or "No readable sections listed"))
                if doc.get("source_url"):
                    st.link_button("Open source label record", doc["source_url"])
                else:
                    st.caption("This PDF has no source URL in its metadata sidecar.")
                if st.button("Generate file description", key=f"describe_{doc['slug']}"):
                    with st.spinner("Summarizing this source file..."):
                        try:
                            summary = requests.post(f"{BACKEND}/documents/describe", json={"slug": doc["slug"]}, timeout=90)
                            summary.raise_for_status()
                            detail = summary.json()
                            st.session_state[f"description_{doc['slug']}"] = detail["description"]
                        except Exception as exc:
                            st.error(f"Could not describe this file. Details: {exc}")
                if st.session_state.get(f"description_{doc['slug']}"):
                    st.write(st.session_state[f"description_{doc['slug']}"])
    except Exception as exc:
        st.error(f"Could not load the source file list from the backend. Details: {exc}")

elif page == "Info" and info_page == "Technologies Used":
    st.title("💻 TECHNOLOGIES USED")
    st.subheader("Application stack")
    st.markdown("""| Component | Technology | Role |
|---|---|---|
| Programming language | Python | Application logic and RAG workflow |
| Frontend | Streamlit | Chat, navigation, source-file descriptions |
| Backend | FastAPI | Chat, retrieval, and document-description endpoints |
| Database | PostgreSQL + pgvector | Store source passages and search embeddings |
| Embeddings | OpenAI text-embedding-3-small | Encode questions and source passages |
| Language model | OpenAI gpt-4o-mini by default | Generate source-grounded answers |
| Deployment | Docker Compose | Run the frontend, API, and database together |""")
    st.subheader("Project files")
    st.markdown("- `app.py`: Streamlit pages and user interface.\n- `api.py`: FastAPI routes for chat and PDF descriptions.\n- `rag_engine.py`: source ingestion, embeddings, retrieval, and grounded generation.\n- `datafiles_docs/`: four official label PDFs and their structured source records.\n- `docker-compose.yml`: local service setup.")
    st.subheader("Data sources")
    st.write("Official label excerpts are retrieved from the openFDA Drug Labeling API. The dataset is a small learning example, not a comprehensive drug database.")
    st.markdown("[openFDA Drug Labeling API documentation](https://open.fda.gov/apis/drug/label/)")

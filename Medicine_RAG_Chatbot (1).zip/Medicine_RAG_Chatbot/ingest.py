"""Re-index the bundled official label excerpts."""
from rag_engine import ingest_sources

if __name__ == "__main__":
    print(f"Inserted {ingest_sources()} new source passages.")

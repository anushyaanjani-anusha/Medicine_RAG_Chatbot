"""RAG operations for official medicine label excerpts."""
import json
import os
from pathlib import Path
from typing import Any

import psycopg
from openai import OpenAI
from pgvector.psycopg import register_vector

ROOT = Path(__file__).parent
DATA_DIR = ROOT / "datafiles_docs"
DB_URL = os.getenv("DATABASE_URL", "postgresql://raguser:ragpass@localhost:5432/medicinerag")
EMBED_MODEL = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
CHAT_MODEL = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")


def client() -> OpenAI:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("Set OPENAI_API_KEY in your .env file before starting the app.")
    return OpenAI(api_key=key)


def connect():
    conn = psycopg.connect(DB_URL, connect_timeout=10)
    register_vector(conn)
    return conn


def init_db() -> None:
    with psycopg.connect(DB_URL, connect_timeout=10) as conn:
        conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        conn.execute("""CREATE TABLE IF NOT EXISTS label_chunks (
            id BIGSERIAL PRIMARY KEY,
            medicine TEXT NOT NULL,
            section TEXT NOT NULL,
            content TEXT NOT NULL,
            source_url TEXT NOT NULL,
            retrieved_at TEXT NOT NULL,
            embedding vector(1536) NOT NULL,
            UNIQUE(medicine, section, content)
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS label_chunks_embedding_idx ON label_chunks USING hnsw (embedding vector_cosine_ops)")


def chunk_text(text: str, max_chars: int = 1000, overlap: int = 150) -> list[str]:
    text = " ".join(text.split())
    if not text:
        return []
    chunks, start = [], 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        if end < len(text):
            boundary = text.rfind(" ", start + max_chars // 2, end)
            if boundary > start:
                end = boundary
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks


def embed(texts: list[str]) -> list[list[float]]:
    response = client().embeddings.create(model=EMBED_MODEL, input=texts)
    return [item.embedding for item in response.data]


def ingest_sources() -> int:
    from pypdf import PdfReader

    init_db()
    pdf_files = sorted(DATA_DIR.glob("*.pdf"))
    count = 0
    with connect() as conn:
        for pdf_path in pdf_files:
            path = pdf_path.with_suffix(".json")
            record = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            medicine = record.get("medicine", pdf_path.stem.replace("_", " ").title())
            source_url = record.get("source_url", "")
            retrieved_at = record.get("retrieved_at", "Unknown")
            sections = record.get("sections", {})
            if not sections:
                pdf_text = "\n\n".join(page.extract_text() or "" for page in PdfReader(str(pdf_path)).pages)
                sections = {"Source document": pdf_text}
            items = []
            for section, body in sections.items():
                for chunk in chunk_text(body):
                    items.append((medicine, section, chunk, source_url, retrieved_at))
            vectors = embed([item[2] for item in items])
            with conn.cursor() as cur:
                for item, vector in zip(items, vectors):
                    cur.execute("""INSERT INTO label_chunks (medicine, section, content, source_url, retrieved_at, embedding)
                        VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT (medicine, section, content) DO NOTHING""", (*item, vector))
                    count += cur.rowcount
    return count


def list_documents() -> list[dict[str, Any]]:
    """Describe the files actually present in the bundled data folder."""
    from pypdf import PdfReader

    result = []
    for pdf_path in sorted(DATA_DIR.glob("*.pdf")):
        path = pdf_path.with_suffix(".json")
        record = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        pages = len(PdfReader(str(pdf_path)).pages)
        result.append({
            "slug": pdf_path.stem,
            "medicine": record.get("medicine", pdf_path.stem.replace("_", " ").title()),
            "generic_name": record.get("generic_name", ""),
            "brand_name": record.get("brand_name", ""),
            "source_name": record.get("source_name", "Official label source"),
            "source_url": record.get("source_url", ""),
            "retrieved_at": record.get("retrieved_at", "Unknown"),
            "sections": list(record.get("sections", {}).keys()),
            "pdf_name": pdf_path.name,
            "pdf_pages": pages,
            "pdf_size_kb": round(pdf_path.stat().st_size / 1024, 1) if pdf_path.exists() else None,
        })
    return result


def describe_document(slug: str) -> dict[str, Any]:
    """Generate a short, source-grounded description of one bundled label PDF."""
    from pypdf import PdfReader

    pdf_path = DATA_DIR / f"{slug}.pdf"
    path = DATA_DIR / f"{slug}.json"
    if not pdf_path.exists() or pdf_path.parent.resolve() != DATA_DIR.resolve():
        raise FileNotFoundError("That label document is not in the project data folder.")
    record = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    text = "\n\n".join(page.extract_text() or "" for page in PdfReader(str(pdf_path)).pages).strip()
    if not text:
        return {"description": "No selectable text was found in this PDF. It may need OCR before the app can describe it.", "source_url": record.get("source_url", ""), "retrieved_at": record.get("retrieved_at", "Unknown")}
    response = client().chat.completions.create(
        model=CHAT_MODEL,
        temperature=0.1,
        messages=[
            {"role": "system", "content": "Write a short neutral description of the supplied official medicine-label excerpt for a student project file catalog. State which label topics and sections it covers. Use only the supplied excerpt. Do not give medical advice, treatment recommendations, or doses. Mention that it represents a specific product label and may not apply to all products."},
            {"role": "user", "content": f"File: {pdf_path.name}\nMedicine: {record.get('medicine', slug)}\nSource: {record.get('source_url', 'Not listed in the sidecar metadata')}\nLabel excerpt:\n{text[:7000]}"},
        ],
    )
    return {"description": response.choices[0].message.content or "No description was generated.", "source_url": record.get("source_url"), "retrieved_at": record.get("retrieved_at")}


def search(question: str, medicine: str | None = None, limit: int = 5) -> list[dict[str, Any]]:
    vector = embed([question])[0]
    with connect() as conn, conn.cursor() as cur:
        if medicine:
            cur.execute("""SELECT medicine, section, content, source_url, retrieved_at,
                    1 - (embedding <=> %s) AS score FROM label_chunks
                    WHERE medicine ILIKE %s ORDER BY embedding <=> %s LIMIT %s""",
                (vector, f"%{medicine}%", vector, limit))
        else:
            cur.execute("""SELECT medicine, section, content, source_url, retrieved_at,
                    1 - (embedding <=> %s) AS score FROM label_chunks
                    ORDER BY embedding <=> %s LIMIT %s""", (vector, vector, limit))
        rows = cur.fetchall()
    return [dict(zip(["medicine", "section", "content", "source_url", "retrieved_at", "score"], row)) for row in rows]


SYSTEM_PROMPT = """You provide general educational information using only the supplied official medicine label excerpts. Do not diagnose, recommend treatment, or give or personalize a dose or dosing schedule. For any dose question, direct the user to the current package label and a licensed doctor or pharmacist. Do not infer that absence from excerpts means a medicine has no risk. If evidence is missing or labels conflict, say so. Distinguish active ingredients from inactive ingredients when the source supports it. Summarize listed uses, ingredients, benefits as label indications, and side effects with plain wording. Every factual claim must be supported by a cited excerpt using [Source N]. For personal medical decisions, advise consulting a licensed doctor or pharmacist. For overdose, severe reaction, or urgent symptoms, advise contacting local emergency services or poison control immediately. Do not use outside knowledge to fill gaps."""


def answer(question: str, medicine: str | None = None) -> dict[str, Any]:
    if medicine is None:
        normalized = question.casefold()
        for name in ("acetaminophen", "paracetamol", "ibuprofen", "amoxicillin", "metformin"):
            if name in normalized:
                medicine = "acetaminophen" if name == "paracetamol" else name
                break
    matches = search(question, medicine=medicine)
    if not matches:
        return {"answer": "I could not find a matching passage in the indexed label records. Try the generic or brand name, or consult a pharmacist.", "sources": []}
    context = []
    sources = []
    for i, m in enumerate(matches, start=1):
        context.append(f"[Source {i}] Medicine: {m['medicine']} | Section: {m['section']}\n{m['content']}")
        sources.append({"id": i, "medicine": m["medicine"], "section": m["section"], "url": m["source_url"], "retrieved_at": m["retrieved_at"], "score": round(float(m["score"]), 3)})
    response = client().chat.completions.create(
        model=CHAT_MODEL,
        temperature=0.1,
        messages=[{"role": "system", "content": SYSTEM_PROMPT},
                  {"role": "user", "content": f"Question: {question}\n\nRetrieved label passages:\n" + "\n\n".join(context)}],
    )
    return {"answer": response.choices[0].message.content or "No answer was generated.", "sources": sources}

# Team video explanations

Add one video per student here before submission. The assignment asks for six individual explanations. Use filenames such as `student_1.mp4` through `student_6.mp4`.
